(function($,window,document){
	"use strict";
     var div= $(".imageD");
     alert(div);
       div.css("width","20%");
       var width=div.width()
       div.css("height",width);
       var im1=$("#1");
       div.css("top","10%");
       div.css("margin-left","10%");
       var im2=$("#2");
       div.css("top","10%");
       div.css("margin-left","35%");
       var im3=$("#3");
       div.css("top","10%");
       div.css("margin-left","60%");
       var im4=$("#4");
       div.css("top","35%");
       div.css("margin-left","10%");
       var im5=$("#5");
       div.css("top","35%");
       div.css("margin-left","35%");
       var im6=$("#6");
       div.css("top","35%");
       div.css("margin-left","60%");
       var im7=$("#7");
       div.css("top","60%");
       div.css("margin-left","10%");
       var im8=$("#8");
       div.css("top","60%");
       div.css("margin-left","35%");
       var im8=$("#8");
       div.css("top","60%");
       div.css("margin-left","60%");
})